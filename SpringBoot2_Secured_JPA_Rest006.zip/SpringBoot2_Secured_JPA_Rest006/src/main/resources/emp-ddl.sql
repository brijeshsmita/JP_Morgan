DROP TABLE emp_rest;
CREATE Table emp_rest(

employee_id numeric(6) primary key,
	
name varchar(30),

salary numeric(6,2));